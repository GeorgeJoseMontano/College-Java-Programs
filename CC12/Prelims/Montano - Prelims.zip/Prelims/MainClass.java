/*
Montano, George Jose P.
20190018801

CC 12 B
Prelim Exam

Problem: Create a Java program that asks for two integers from the user. 
Assume the user input (row, col) be the initial position of the knight, 
Identify all possible moves for the knight in the given board 
Mark all possible moves to 2
(Optional) Modify/Beautify the print_board()

*/
class MainClass
{
	public static void main(String args[])
	{
		int row = Integer.parseInt(args[0]);
		int col = Integer.parseInt(args[1]);
		
		if (row < 1 || row > 8 || col < 1 || col > 8)
		{
			System.out.println("Input is Out of Bounds...Ending Program");
			System.exit(0);
		}
		
		Board b = new Board();
		//Initial
		System.out.println("Printing Initial Board Values");
		b.print_board();
		
		//User Input Placement
		b.set_cell(row-1, col-1, 1);
		System.out.println("Printing the board with Knight placed in row = " +row+ " col= " +col+ " and set to 1");
		b.print_board();
		
		//Possible Moves
		if (row + 1 < 8 && col - 2 > 0)
		{
			b.set_cell(row+1, col-2, 2);
		}
		if (row + 1 < 8 && col < 8)
		{
			b.set_cell(row+1, col, 2);
		}
		if (row - 3 > 0 && col - 2 > 0)
		{
			b.set_cell(row-3, col-2, 2);
		}
		if (row - 3 > 0 && col < 8)
		{
			b.set_cell(row-3, col, 2);	
		}
		if (row < 8 && col - 3 > 0)
		{
			b.set_cell(row, col-3, 2);
		}
		if (row - 2 > 0 && col - 3 > 0)
		{
			b.set_cell(row-2, col-3, 2);
		}
		if (row < 8 && col + 1 < 8)
		{
			b.set_cell(row, col+1, 2);
		}
		if (row - 2 > 0 && col + 1 < 8)
		{	
			b.set_cell(row-2, col+1, 2);
		}	
		System.out.println("Printing the board with possible moves for Knight");
		b.print_board();
	}
}