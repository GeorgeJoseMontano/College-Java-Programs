/*
Montano, George Jose P.
20190018801

CC 12 B
Prelim Exam

Problem: Create a Java program that asks for two integers from the user. 
Assume the user input (row, col) be the initial position of the knight, 
Identify all possible moves for the knight in the given board 
Mark all possible moves to 2
(Optional) Modify/Beautify the print_board()

*/

class Board
{
	int[][] board;
	
	public Board()
	{
		this.board = new int [8][8];
		
		for (int i=0; i<8; i++)
		{
			for (int ii=0; ii<8;ii++)
			{
				this.board[i][ii] = 0;
			}
		}
	}
	//Board print
	public void print_board()
	{
		for (int i=0; i<8; i++)
		{
			for (int ii=0; ii<8;ii++)
			{
				if(this.board[i][ii] == 1 || this.board[i][ii] == 2)
				{
				System.out.print("|" + this.board[i][ii] + "|");
				}
				else
				{
					System.out.print("|_|");
				}
			}
			System.out.println();	
		}
		System.out.println();
	}
	//Replace cell with new value
	public void set_cell(int row, int col, int value) 
	{
		this.board[row][col] = value;
	}
}