/**
  * Another implementation of a stack
  * uses linked list
  */
class OurListStack {

    // push(int value)
    // int pop()
    // print()
    // size()


}
